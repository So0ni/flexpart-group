class A {
    public:
    A() noexcept {};
};
int main()
{
   A a = A();
   return 0;
}
