c
      common /comrec/ nwrep,ndup
c 
