C
       character*256 CPPBASE
c
       COMMON /COMBASE/ CPPBASE
C
