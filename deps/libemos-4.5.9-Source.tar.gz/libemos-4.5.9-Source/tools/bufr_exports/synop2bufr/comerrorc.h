C
C     'COMERRORC' contains parameters need for manual error correction 
C
      COMMON / COMERRORC / youtfile
C
C                         youtfile - output file name for error bulletin
