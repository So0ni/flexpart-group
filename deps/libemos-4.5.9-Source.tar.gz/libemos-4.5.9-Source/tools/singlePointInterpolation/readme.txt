

gfortran -o singlePointInterpolation singlePointInterpolation.F $EMOSLIB

or 

pgf90 -o singlePointInterpolation singlePointInterpolation.F $EMOSLIB


################ OLD and WRONG? COMMENT ##############

it works just for spectral input fields
