C Copyright 1981-2016 ECMWF.
C
C This software is licensed under the terms of the Apache Licence 
C Version 2.0 which can be obtained at http://www.apache.org/licenses/LICENSE-2.0.
C
C In applying this licence, ECMWF does not waive the privileges and immunities 
C granted to it by virtue of its status as an intergovernmental organisation 
C nor does it submit to any jurisdiction.
C
      INTEGER QG064(64)
      DATA QG064/
     X  20,  30,  40, 48,
     X  54,  64,  72, 80,
     X  90,  90, 100, 108,
     X  120, 120, 128, 144,
     X 144, 144, 150, 160,
     X 160, 180, 180, 180,
     X 192, 192, 192, 200,
     X 200, 216, 216, 216,
     X 240, 240, 240, 240,
     X 240, 240, 240, 250,
     X 250, 250, 250, 256,
     X 256, 256, 256, 256,
     X 256, 256, 256, 256,
     X 256, 256, 256, 256,
     X 256, 256, 256, 256,
     X 256, 256, 256, 256 /
